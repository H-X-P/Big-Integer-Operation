package cryptography;

import java.math.BigInteger;
import java.util.Random;
import java.util.Scanner;

public class Operation {
	/**
	 * 大数加法
	 * @param one  加数
	 * @param two  加数
	 * @return     结果
	 */
	public static String Add(String one,String two) {
		if(one.equals("0"))
			return two;
		if(two.equals("0"))
			return one;
		int length1=one.length();
		int length2=two.length();
		char[] Long=null,Short=null;
		int i,max=0,min=0,carry=0,num1,num2,front1=0,front2=0,isNegative1=0,isNegative2=0,oneLong=0;
		if(one.charAt(0)=='-') {   //第一个数是负数
			isNegative1=1;
			front1++;   //前驱
			length1--;   //长度减1
		}
		if(two.charAt(0)=='-') {
			isNegative2=1;
			front2++;
			length2--;
		}
		if(length1>length2) {   //保证第一个数的数值大于第二个数的数值，方便操作
			max=one.length();
			min=two.length();
			Long=one.toCharArray();
			Short=two.toCharArray();
			oneLong=1;   //第一个数大
		}
		else if(length1<length2){
			max=two.length();
			min=one.length();
			Long=two.toCharArray();
			Short=one.toCharArray();
		}
		else {
			int j,k;
			for(j=front1,k=front2;j<one.length();j++,k++) {
				if(one.charAt(j)>two.charAt(k)) {
					max=one.length();
					min=two.length();
					Long=one.toCharArray();
					Short=two.toCharArray();
					oneLong=1;
					break;
				}else if(one.charAt(j)<two.charAt(k)){
					max=two.length();
					min=one.length();
					Long=two.toCharArray();
					Short=one.toCharArray();
					break;
				}
			}
			if(j==one.length()) {   //数值相等
				if(isNegative1==isNegative2) {   //符号相等
					max=one.length();
					min=two.length();
					Long=one.toCharArray();
					Short=two.toCharArray();
				}else {
					//System.out.println("Add result=0");
					return "0"; 
				}  
			}
		}
		int[] result=new int[length1>length2?length1+1:length2+1];
		String number="";
		if(isNegative1==isNegative2) {   //符号相等
			for(i=0;min>front1;i++) {   //front1=front2
				num1=Long[--max]-48;
				num2=Short[--min]-48;
				result[i]=(num1+num2+carry)%10;
				carry=(num1+num2+carry)/10;
			}
			while (max>front1) {   //剩下的继续加
				num1=Long[--max]-48;
				result[i++]=(num1+carry)%10;
				carry=(num1+carry)/10;
			}
			if(carry==1)   //最高位有进位
				result[i]=1;
			if(isNegative1==1)
				number+='-';
			if(result[i]!=0)
				number+=String.valueOf(result[i--]);
			else
				i--;   //如果首位是0则跳过
			for(;i>=0;i--)   //转化为字符串
				number+=String.valueOf(result[i]);
		}else {
			if(oneLong==1) {
				length1=front2;
				length2=front1;
				if(isNegative1==1)
					number+="-";
			}else {
				length1=front1;
				length2=front2;
				if(isNegative2==1)
					number+="-";
			}
			for(i=0;min>length1;i++) {
				num1=Long[--max]-48;
				num2=Short[--min]-48;
				result[i]=(num1-num2+10+carry)%10;
				if(num1-num2+carry<0)
					carry=-1;
				else
					carry=0;
			}
			while(max>length2) {   //多余的继续减
				num1=Long[--max]-48;
				result[i++]=(num1+10+carry)%10;
				if(num1+carry<0)
					carry=-1;
				else
					carry=0;
			}
			while(i>0&&result[--i]==0);   //如果是0则跳过
			for(;i>=0;i--) 
				number+=String.valueOf(result[i]);
		}
		//System.out.println("Add result="+number);
		return number;
	}
	/**
	 * 大数模加
	 * @param one  加数
	 * @param two  加数
	 * @param mod  模
	 * @return     结果
	 */
	public static String Add(String one,String two,String mod) {
		String number=Add(one, two);
		if(number.charAt(0)!='-')
			return Mod(number, mod);
		else {
			String result="";
			for(int i=1;i<number.length();i++)
				result+=number.charAt(i);
			result=Mod(result, mod);
			if(result.equals("0"))
				return "0";
			return Subtract(mod, result);
		}
		/*carry=0;
		for(i--;i>=0;i--)
			carry=(carry*10+result[i])%mod;
		System.out.print(carry);*/
	}
	/**
	 * 大数减法
	 * @param one  被减数
	 * @param two  减数
	 * @return     结果
	 */
	public static String Subtract(String one,String two) {
		if(one.equals(two)) {   //两个数的数值和符号均相同，结果为0
			//System.out.println("Sub result=0");
			return "0";
		}
		if(two.equals("0"))
			return one;
		int length1=one.length();
		int length2=two.length();
		char[] Big=null,Small=null;
		int i=0,num1,num2,carry=0,front1=0,front2=0,isNegative1=0,isNegative2=0,min=0,max=0,oneLong=0;
		if(one.charAt(0)=='-') {   //第一个数是负数
			isNegative1=1;
			front1++;   //前驱
			length1--;   //长度减1
		}
		if(two.charAt(0)=='-') {
			isNegative2=1;
			front2++;
			length2--;
		}
		if(length1>length2) {   //保证第一个数大于第二个数，如果是负数只是符号不同，数值还是一样的
			max=one.length();
			min=two.length();
			Big=one.toCharArray();
			Small=two.toCharArray();
			oneLong=1;
		}else if(length1<length2) {
			max=two.length();
			min=one.length();
			Big=two.toCharArray();
			Small=one.toCharArray();
		}else {   //长度相等
			int j,k;
			for(j=front1,k=front2;j<one.length();j++,k++) {
				if(one.charAt(j)>two.charAt(k)) {
					max=one.length();
					min=two.length();
					Big=one.toCharArray();
					Small=two.toCharArray();
					oneLong=1;
					break;
				}else if(one.charAt(j)<two.charAt(k)){
					max=two.length();
					min=one.length();
					Big=two.toCharArray();
					Small=one.toCharArray();
					break;
				}
			}
			if(j==one.length()) {   //数值相同，符号不同
				max=one.length();
				min=two.length();
				Big=one.toCharArray();
				Small=two.toCharArray();
				oneLong=1;
			}
		}
		String number="";
		int[] result=new int[max+1];
		if(isNegative1==isNegative2) {   //符号相同
			for(i=0;min>front2;i++) {   //front1==front2
				num1=Big[--max]-48;
				num2=Small[--min]-48;
				result[i]=(num1-num2+10+carry)%10;
				if(num1-num2+carry<0)
					carry=-1;
				else
					carry=0;
			}
			while(max>front1) {   //多余的继续减
				num1=Big[--max]-48;
				result[i++]=(num1+10+carry)%10;
				if(num1+carry<0)
					carry=-1;
				else
					carry=0;
			}
			while(i>0&&result[--i]==0);   //如果是0则跳过
			if((isNegative1==0&&oneLong!=1)||(isNegative1==1&&oneLong==1))
				number+="-";   //正减正，第一个小 或 负减负，第一个大
			for(;i>=0;i--) 
				number+=String.valueOf(result[i]);
		}else {
			if(oneLong==1) {
				length1=front2;
				length2=front1;
			}else {
				length1=front1;
				length2=front2;
			}
			for(i=0;min>length1;i++) {
				num1=Big[--max]-48;
				num2=Small[--min]-48;
				result[i]=(num1+num2+carry)%10;
				carry=(num1+num2+carry)/10;
			}
			while (max>length2) {   //剩下的继续加
				num1=Big[--max]-48;
				result[i++]=(num1+carry)%10;
				carry=(num1+carry)/10;
			}
			if(carry==1)   //最高位有进位
				result[i]=1;
			if(isNegative1==1)
				number+='-';
			if(result[i]!=0)
				number+=String.valueOf(result[i--]);
			else
				i--;   //如果首位是0则跳过
			for(;i>=0;i--)   //转化为字符串
				number+=String.valueOf(result[i]);
		}
		//System.out.println("Sub result="+number);
		return number;		
	}
	/**
	 * 大数模减
	 * @param one  被减数
	 * @param two  减数
	 * @param mod  模
	 * @return     结果
	 */
	public static String Subtract(String one,String two,String mod) {
		String number=Subtract(one, two);
		if(number.charAt(0)!='-')
			return Mod(number, mod);
		else {
			String result="";
			for(int i=1;i<number.length();i++)
				result+=number.charAt(i);
			result=Mod(result, mod);
			if(result.equals("0"))
				return "0";
			return Subtract(mod, result);
		}
	}
	/**
	 * 大数乘法
	 * @param one  乘数
	 * @param two  乘数
	 * @return     结果
	 */
	public static String Multiply(String one,String two) {
		if(one.equals("0")||two.equals("0"))
			return "0";
		int length1=one.length();
		int length2=two.length();
		char[] One=one.toCharArray();
		char[] Two=two.toCharArray();
		int isNegative=0,front1=0,front2=0;
		if(One[front1]=='-') {
			isNegative^=1;
			front1++;
		}
		if(Two[front2]=='-') {
			isNegative^=1;
			front2++;
		}
		int i,j,k=0,carry,num1,num2,temp,carry1;
		int[] result=new int[length1+length2];
		for (i = length1-1; i >= front1; i--) {   //最多执行乘数的长度次
			num1=One[i]-48;
			k=length1-i-1;
			carry=0;
			for (j = length2-1; j >= front2; j--,k++) {
				num2=Two[j]-48;
				temp=(num1*num2+carry)%10;
				carry1=(result[k]+temp)/10;
				result[k]=(result[k]+temp)%10;
				carry=(num1*num2+carry)/10+carry1;   //相乘产生的进位和之后相加产生的进位
			}
			if(carry!=0)
				result[k]=carry;
		}
		String number="";
		if(isNegative==1)
			number+='-';
		if(result[k]!=0)   //如果首位是0则跳过
			number+=String.valueOf(result[k--]);
		else
			k--;
		for(;k>=0;k--)
			number+=String.valueOf(result[k]);
		//System.out.println("Multiply result="+number);
		return number;
	}
	/**
	 * 大数模乘
	 * @param one  乘数
	 * @param two  乘数
	 * @param mod  模
	 * @return     结果
	 */
	public static String Multiply(String one,String two,String mod) {
		String number=Multiply(one, two);
		if(number.charAt(0)!='-')
			return Mod(number, mod);
		else {
			String result="";
			for(int i=1;i<number.length();i++)
				result+=number.charAt(i);
			result=Mod(result, mod);
			if(result.equals("0"))
				return "0";
			return Subtract(mod, result);
		}
	}
	/**
	 * 大数除法
	 * @param one  被除数
	 * @param two  除数
	 * @return     结果
	 */
	public static String Division(String one,String two) {
		if(one.equals("0"))
			return "0";
		if(one.equals(two)) {   //两个数的数值相等，符号也相等，商为1，余数为0
			//System.out.println("Division result=1");
			return "1";
		}
		int length1=one.length();   //被除数长度
		int length2=two.length();   //除数长度
		int isNegative=0,front1=0,front2=0;
		if(one.charAt(0)=='-') {
			isNegative^=1;
			length1--;
			front1++;
		}
		if(two.charAt(0)=='-') {
			isNegative^=1;
			length2--;
			front2++;
		}
		char[] Big=null,Small=null;
		int difference=0;   //两个数相差的位数，循环difference+1次
		if(length1<length2) {   //被除数小于除数，商为0，余数为被除数
			//System.out.println("Division result=0");
			return "0";
		}else if(length1>length2) {   //被除数大于除数
			Big=one.toCharArray();
			Small=two.toCharArray();
			difference=length1-length2;
		}else {
			for(int i=front1,j=front2;length1!=0;i++,j++,length1--) {
				if(one.charAt(i)>two.charAt(j)) {   //被除数大于除数
					Big=one.toCharArray();
					Small=two.toCharArray();
					difference=0;
					break;
				}else if(one.charAt(i)<two.charAt(j)) {   //被除数小于除数，商为0，余数为被除数
					//System.out.println("Division result=0");
					return "0";
				}
			}
			if(length1==0) {   //两个数的数值相等，但符号不同
				//System.out.println("Division result=-1");
				return "-1";
			}
			length1=length2;
		}
		//转化为整型数组
		int[] Long=new int[length1];
		int[] Short=new int[length2];
		for(int i=0,j=front1;i<length1;i++,j++)
			Long[i]=Big[j]-48;
		for(int i=0,j=front2;i<length2;i++,j++)
			Short[i]=Small[j]-48;
		
		int[] result=new int[length1];
		int front=0,back,length=0,flag,carry,num,point=0;
		//front和back确定每轮的被除数，front确定被除数第一位，back确定被除数最后一位
		//flag是是否可以做减法的标记
		for(back=length1-difference-1;back<length1;back++,point++) {   //循环difference+1次
			while(front<=back&&Long[front]==0){   //front不能超过back，如果front指着的是0则后移
				front++;
				length=back-front+1;   //长度+1
			}
			length=back-front+1;   //被除数长度
			flag=0;
			if(length==length2) {   //被除数和除数长度相等，判断被除数是否够减
				for(int i=front,j=0;i<=back;i++,j++) {
					if(Long[i]<Short[j]) {   //被除数小于除数，不能做减法
						flag=1;
						break;
					}else if(Long[i]>Short[j])
						break;
				}
				if (flag==1)
					continue;
			}else if(length<length2)   //被除数长度小于除数，不能做减法
				continue;
			while(flag==0) {   //允许做减法
				result[point]++;
				int temp=0;
				carry=0;   //进位
				for(int i=back,j=length2-1;j>=0;i--,j--) {   //减法
					temp=i;
					num=Long[i];
					Long[i]=(num-Short[j]+10+carry)%10;
					if(num-Short[j]+carry<0)
						carry=-1;
					else
						carry=0;
				}
				while(temp!=front) {   //多出来的继续减
					num=Long[--temp];
					Long[temp]=(num+10+carry)%10;
					if(num+carry<0)
						carry=-1;
					else
						carry=0;
				}
				while(front<=back&&Long[front]==0){   //front不能超过back，如果front指着的是0则后移
					front++;
					length=back-front+1;
				}
				if(length==length2) {
					for(int i=front,j=0;i<=back;i++,j++) {
						if(Long[i]<Short[j]) {
							flag=1;
							break;
						}else if(Long[i]>Short[j])   //继续做减法
							break;
					}
				}else if(length<length2)
					flag=1;
			}
		}
		String number="";
		if(isNegative==1)
			number+='-';
		int i=0;
		while(result[i++]==0);
		for(i--;i<point;i++)
			number+=String.valueOf(result[i]);
		//System.out.println("divide result="+number);
		return number;
	}
	/**
	 * 大数模除
	 * @param one  被除数
	 * @param two  除数
	 * @param mod  模
	 * @return     结果
	 */
	public static String Division(String one,String two,String mod) {
		String number=Division(one, two);
		if(number.charAt(0)!='-')
			return Mod(number, mod);
		else {
			String result="";
			for(int i=1;i<number.length();i++)
				result+=number.charAt(i);
			result=Mod(result, mod);
			if(result.equals("0"))
				return "0";
			return Subtract(mod, result);
		}
	}
	/**
	 * 大数取模
	 * @param one  数
	 * @param mod  模
	 * @return     结果
	 */
	public static String Mod(String one,String mod) {
		if(one.equals("0")) {
			//System.out.println("Mod result=0");
			return one;
		}
		if(one.equals(mod)) {   //两个数相等，商为1，余数为0
			//System.out.println("Mod result=0");
			return "0";
		}
		int length1=one.length();   //被除数长度
		int length2=mod.length();   //除数长度
		char[] Big=null,Small=null;
		int difference=0,front1=0,front2=0,isNegative1=0;   //两个数相差的位数，循环difference+1次
		if(one.charAt(0)=='-') {   //第一个数是负数
			isNegative1=1;
			front1++;   //前驱
			length1--;   //长度减1
		}
		if(mod.charAt(0)=='-') {
			front2++;
			length2--;
		}
		if(length1<length2) {   //被除数小于除数，商为0，余数为被除数
			//System.out.println("Mod result="+one);
			return one;
		}else if(length1>length2) {   //被除数大于除数
			Big=one.toCharArray();
			Small=mod.toCharArray();
			difference=length1-length2;
		}else {
			for(int i=0;i<length1;i++) {
				if(one.charAt(i)>mod.charAt(i)) {   //被除数小于除数，商为0，余数为被除数
					Big=one.toCharArray();
					Small=mod.toCharArray();
					difference=0;
					break;
				}else if(one.charAt(i)<mod.charAt(i)) {   //被除数小于除数，商为0，余数为被除数
					//System.out.println("Mod result="+one);
					return one;
				}
			}
		}
		//转化为整型数组
		int[] Long=new int[length1];
		int[] Short=new int[length2];
		for(int i=front1;i<length1;i++)
			Long[i]=Big[i]-48;
		for(int i=front2;i<length2;i++)
			Short[i]=Small[i]-48;
		
		int front=0,back,length=0,flag,carry,num;
		//front和back确定每轮的被除数，front确定被除数第一位，back确定被除数最后一位
		//flag是是否可以做减法的标记
		for(back=length1-difference-1;back<length1;back++) {   //循环difference+1次
			while(front<=back&&Long[front]==0){   //front不能超过back，如果front指着的是0则后移
				front++;
				length=back-front+1;   //长度+1
			}
			length=back-front+1;   //被除数长度
			flag=0;
			if(length==length2) {   //被除数和除数长度相等，判断被除数是否够减
				for(int i=front,j=0;i<=back;i++,j++) {
					if(Long[i]<Short[j]) {   //被除数小于除数，不能做减法
						flag=1;
						break;
					}else if(Long[i]>Short[j])
						break;
				}
				if (flag==1)
					continue;
			}else if(length<length2)   //被除数长度小于除数，不能做减法
				continue;
			while(flag==0) {   //允许做减法
				int temp=0;
				carry=0;   //进位
				for(int i=back,j=length2-1;j>=0;i--,j--) {   //减法
					temp=i;
					num=Long[i];
					Long[i]=(num-Short[j]+10+carry)%10;
					if(num-Short[j]+carry<0)
						carry=-1;
					else
						carry=0;
				}
				while(temp!=front) {   //多出来的继续减
					num=Long[--temp];
					Long[temp]=(num+10+carry)%10;
					if(num+carry<0)
						carry=-1;
					else
						carry=0;
				}
				while(front<=back&&Long[front]==0){   //front不能超过back，如果front指着的是0则后移
					front++;
					length=back-front+1;
				}
				if(length==length2) {
					for(int i=front,j=0;i<=back;i++,j++) {
						if(Long[i]<Short[j]) {
							flag=1;
							break;
						}else if(Long[i]>Short[j])   //继续做减法
							break;
					}
				}else if(length<length2)
					flag=1;
			}
		}
		if(length==0) {   //余数为0，说明除数整除被除数
			//System.out.println("Mod result=0");
			return "0";
		}
		else {
			back--;
			String number="";
			if(isNegative1==1)
				number+='-';
			for(int i=front;i<=back;i++)
				number+=String.valueOf(Long[i]);
			//System.out.println("Mod result="+number);
			return number;
		}
	}
	/**
	 * 快速幂取模
	 * @param one  底数
	 * @param two  指数
	 * @param mod  模
	 * @return     结果
	 */
	public static String Power(String one,String two,String mod) {
		if(two.equals("0")) {   //0次幂结果为1
			//System.out.println("Power result=1");
			return "1";
		}else if(two.equals("1")){   //1次幂结果为它本身
			return Mod(one, mod);
		}
		String count=two,result="1",temp=one;
		while(!count.equals("0")){
			if(Mod(count, "2").equals("1"))   //看它二进制最后一位是不是1
				result=Multiply(result, temp, mod);
			if(!count.equals("1"))
				temp=Multiply(temp, temp, mod);
			count=Division(count, "2");
		}
		//System.out.println(result);
		return result;
	}
	/**
	 * 最大公约数
	 * @param one
	 * @param two
	 * @return     结果
	 */
	public static String GCD(String one,String two) {
		if(one.equals(two)) {
			//System.out.println("GCD="+one);
			return one;
		}
		int length1=one.length();
		int length2=two.length();
		String first=null,second=null,temp=null;
		if(length1>length2) {   //保证第一个数大于第二个
			first=one;
			second=two;
		}else if(length1<length2) {
			first=two;
			second=one;
		}else {
			for (int i = 0; i < length1; i++) {
				if(one.charAt(i)>two.charAt(i)) {
					first=one;
					second=two;
					break;
				}
				else if(one.charAt(i)<two.charAt(i)) {
					first=two;
					second=one;
					break;
				}
			}
		}
		while(!second.equals("0")) {
			temp=Mod(first, second);
			first=second;
			second=temp;
		}
		//System.out.println("GCD="+first);
		return first;
	}
	/**
	 * 扩展欧几里得
	 */
	static String x= "0",y= "0";
	public static String ExtendGCD(String a,String b) {
		if(b.equals("0")) {
			Operation.x="1";
			Operation.y="0";
			return a;
		}
		String d=ExtendGCD(b, Mod(a, b));
		String temp=Operation.x;
		Operation.x=Operation.y;
		Operation.y=Subtract(temp, Multiply(Division(a, b), Operation.y));
		//System.out.println("    "+Operation.x);
		//System.out.println("    "+Operation.y);
		return d;
	}
	/**
	 * 乘法逆
	 * @param a
	 * @param mod
	 * @return
	 */
	public static String MultiplicativeInverse(String a,String mod) {
		String d=ExtendGCD(a,mod);
		if(d.equals("1"))
			return Add(Mod(Operation.x, mod), mod, mod);
		return "-1";
	}
	/*int版本乘法逆
	 static int x=0,y=0;
	 public static int ExtendGCD(int a,int b) {
		if(b==0) {
			Operation.x=1;
			Operation.y=0;
			return a;
		}
		int d=ExtendGCD(b, a%b);
		int temp=Operation.x;
		Operation.x=Operation.y;
		Operation.y=temp-a/b*y;
		System.out.println("    x="+Operation.x);
		System.out.println("    y="+Operation.y);
		return d;
	}
	//乘法逆
	public static int MultiplicativeInverse(String a,String mod) {
		int b=Integer.parseInt(mod);
		int d=ExtendGCD(Integer.parseInt(a),b);
		if(d==1)
			return (Operation.x%b+b)%b;
		return -1;
	}*/
	/**
	 * 米勒罗宾算法
	 * @param one
	 * @return
	 */
	public static boolean MillerRabin(String one) {
		if(one.equals("0")||one.equals("1"))   //0和1不是素数
			return false;
		if(one.equals("2"))   //2是素数
			return true;
		if((one.charAt(one.length()-1)-48)%2==0)   //偶数不是素数
			return false;
		String number=Subtract(one, "1");   //计算n-1
		String number1=number;
		int count=0;
		while((number1.charAt(number1.length()-1)-48)%2==0) {   //n-1=m*2^t
			number1=Division(number1, "2");
			count++;
		}
		for(int i=1;i<=5;i++) {   //(a^(n-1))%n=(a^(m*2^t))%n
			String random=String.valueOf(i+2);
			String x=Power(random, number, one);   //(a^m)%n
			String y="";
			for(int j=1;j<=count;j++) {   //((a^m)^(2^t))%n
				y=Multiply(x, x, one);
				if(y.equals("1")&&!x.equals("1")&&!x.equals(number))   //如果不满足二次探测定理，则不是素数
					return false;
				x=y;
			}
			if(!y.equals("1"))   //如果不满足费马小定理，则不是素数
				return false;
		}
		return true;
	}
	/**
	 * 生成素数算法
	 * @return      素数
	 */
	public static String PrimeGeneration() {
		String[] table= {"3","7","11","13","17","19","23","29","31","37","41","43","47",
				"53","59","61","67","71","73","79","83","89","97","101","103","107","109",
				"113","127","131","137","139","149","151","157","163","167","173","179",
				"181","191","193","197","199","211","223","227","229","233","239","241",
				"251","257","263","269","271","277","281","283","293","307","311","313",
				"317","331","337","347","349","353","359","367","373","379","383","389",
				"397","401","409","419","421","431","433","439","443","449","457",
				"461","463","467","479","487","491","499"};
		Random random=new Random();
		int flag;
		long time1=System.currentTimeMillis();
		while(true) {
			String number="";
			for(int i=1;i<=33;i++)
				number+=String.valueOf(random.nextInt(899999998)+100000001);
			System.out.println(number);
			int num=random.nextInt(800)+101;
			if(num%2==0)
				num++;
			for(int i=1;i<=50;i++,num+=2) {
				String temp="";
				if(num%5==0)
					num+=2;
				temp=temp+number+String.valueOf(num);
				flag=0;
				for(int j=0;j<table.length;j++) {
					if(Mod(temp, table[j]).equals("0")) {
						flag=1;
						break;
					}
				}
				if(flag==1)
					continue;
				else
					if(MillerRabin(temp)) {
						System.out.println("素数: "+temp);
						System.out.println("时间差="+(System.currentTimeMillis()-time1)+"ms");
						return temp;
					}
			}
		}
	}
//300位十进制素数
//672941681148975298740103988194950732324084506645975671547438171801779849155881016662135515852141855508018111249802448589045695430962032572255080796768159495801098288490645586583061143412129237706910931665797564183101196183931648498851138775014647258556711608136721273299390310827353066456957483639299
//653019612556501519799298743457416049644112642538022891970393604440826342962375403720019685529449159718328869706451453904729043363311128134314652783382635354943200999768800997891435767880617995797535786218749398243056261799107448790858138589691618706130127545255753594588114022056549050540769155658473
//633618469110717278826192361819953378782823614576857413631846555110599845722898083174176514731241284476932540647889862815709814550941090934946888650933182707483048620384370956936294373170463778773346142951133642888026761132219868094156869714386175168482658308355552550564978307539148000267493367841813
//424107833943429975241093898450825267891862796944252305221226924823362812489468305780680866972150106387106595149517467261008275791806030277766268172725388217192150466389257802016289998687952425918528537525275487218698994104537313158564350751861970536523921135763795575883324452839695301396201629858351
//263450520411275743790435964256785916212721035307964502212230889120282320986637437747541571688444165377391928501784188860376250478772269201701404341732611195840860966771558984913243186324081264561447722290354549484034446143611249546948222318614596057034385281318641645726612880282250008510325761957423
//957545770545409238107967850230314640502544490547391888989489151145686666567165195274402454274640890826319471543414807238989883219233669467258903681725439265495910146657951886020001361649958948863282436989370986637021552286898614882006538893175417827746119795795689588908449212405902390001212451699329
//441086924207357169349015133865044518915630381193259605633012246574277046670283011582898312896969115898596167295361720502762128945945960271823032714619036905016537800919382228404799251254281153583447609897366405288166734993866240237076356211959264491762451098329993028352417738154106924308507164338727
//214870052980815367577291784627902708719802277128149369356311939236596853366271103968812931332145864571367016263259506949201985903708991330657005820918132219051420306215369688007649436101361885347977415827831904465125972681277283243530766501893543832374257674319643447978284232131374047798140761172317
//631626420496620233289373592798799740564382324280898984865184495895938538961219721642885626115443005505920806748260468240497764563935616111158859821116213433675063188845933807483928589905861253969538706242426938954755140097884559449075630838991212970788967494746830818582432462041817494586249022196831
//517401327900541484517232598775314454171199880679609566146224215751548574157444562205171566331803354966837226929264828169515016616309812153488683213660755893694760590549238366363955217664129399350009704947649643411236695835665347652626636520252322504378491481202387241276111683264220199769877493116207
//955042930633410289133616296687431777269353980956568253574985061454859846383784618868936295454149058329055354262839296541908590329891268218404276396709186373481902442299599349413886590143757678944807286223232776732690994758060943148907454012806238319657554857310557054678934303822406793932126613431907
//886561163228838664750509032768759020351470065461506216295171421466522603290150530199373404129571069480539452635354057998985307892246327624821492158196842621382357442511837684610582698182410676560942977011624164506742932167839443913503332061016760221262755081522835308001246894308971214499396769460513
	public static void main(String[] args) {
		String string="214870052980815367577291784627902708719802277128149369356311939236596853366271103968812931332145864571367016263259506949201985903708991330657005820918132219051420306215369688007649436101361885347977415827831904465125972681277283243530766501893543832374257674319643447978284232131374047798140761172317";
		BigInteger a=new BigInteger(string);
		if(a.isProbablePrime(1024))
			System.out.println("素数");
		else
			System.out.println("合数");
		System.out.println("\t1.模加\n\t2.模减\n\t3.模乘\n\t4.模除\n\t5.模取余\n\t6.幂模"
				+ "\n\t7.GCD\n\t8.乘法逆\n\t9.素数判定\n\t10.生成大素数");
		Scanner scanner=new Scanner(System.in);
		System.out.println("Please enter the first number: ");
		String one=scanner.nextLine();
		System.out.println("Please enter the second number: ");
		String two=scanner.nextLine();
		System.out.println("Please enter the mod number: ");
		String three=scanner.nextLine();
		System.out.println("Please enter the mode: ");
		int mode=scanner.nextInt();
		switch (mode) {
		case 1:
			Add(one, two,three);
			break;
		case 2:
			Subtract(one, two,three);
			break;
		case 3:
			Multiply(one,two,three);
			break;
		case 4:
			Division(one, two, three);
			break;
		case 5:
			Mod(one, two);
			break;
		case 6:
			Power(one, two, three);
			break;
		case 7:
			GCD(one,two);
			break;
		case 8:
			System.out.println(one+"模"+two+"的乘法逆元="+MultiplicativeInverse(one, two));
			break;
		case 9:
			if(MillerRabin(one))
				System.out.println("素数");
			else
				System.out.println("合数");
			break;
		case 10:
			PrimeGeneration();
			break;
		default:
			break;
		}
		scanner.close();
	}
}
